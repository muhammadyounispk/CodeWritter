<?php
header("Content-Type: application/json");
define("TOKEN_EXPIRY_TIME",50000000000000000000000000); //sec
include_once '../common/database.php';
include_once 'functions.php';


$bearer_token = get_bearer_token();
$is_jwt_valid = is_jwt_valid($bearer_token);
$is_jwt_valid=true; //development phase OPEN API
$function_name = @$_REQUEST['j'];

if ($function_name == 'login') {
	login();
} else {
	if ($is_jwt_valid) {
		switch ($function_name) {
			case 'login()':
				login();
				break;
			case 'display_stories()':
				 echo display_stories();
				break;
			case 'display_categories()':
				 echo display_categories();
				break;
			case 'display_genre()':
				 echo display_genre();
				break;
			default:
				echo json_encode(array("response" => 404, "description" => "  \" " . @$params[1] . "() \"  not  Found"));
		}
	} else {
		echo json_encode(array("response" => 402, "description" => "INVALID ACCESS TOKEN"));
	}
}

